const express = require('express');
const cors = require('cors');
const mongoose = require('mongoose');
const dotenv = require('dotenv');
dotenv.config();
const app = express();
app.use(cors());
app.use(express.json());

const mongoUri = process.env.MONGODB_URI || 'mongodb://127.0.0.1:27017/bookitdb';
mongoose.connect(mongoUri, { useNewUrlParser: true, useUnifiedTopology: true })
  .then(()=> console.log('MongoDB connected'))
  .catch(err => console.error('MongoDB connection error:', err));

/**
 * Simple schemas: Experience, Slot (embedded), Booking, Promo
 */
const SlotSchema = new mongoose.Schema({
  startTime: Date,
  endTime: Date,
  availableSeats: Number
}, { _id: true });

const ExperienceSchema = new mongoose.Schema({
  title: String,
  shortDescription: String,
  longDescription: String,
  priceCents: Number,
  imageUrl: String,
  slots: [SlotSchema]
}, { timestamps: true });

const BookingSchema = new mongoose.Schema({
  experienceId: { type: mongoose.Schema.Types.ObjectId, ref: 'Experience' },
  slotId: mongoose.Schema.Types.ObjectId,
  userName: String,
  userEmail: String,
  numPeople: Number,
  pricePaidCents: Number,
  promoCode: String,
  status: { type: String, default: 'confirmed' }
}, { timestamps: true });

const PromoSchema = new mongoose.Schema({
  code: { type: String, unique: true },
  type: String,
  value: Number,
  expiresAt: Date
}, { timestamps: true });

const Experience = mongoose.model('Experience', ExperienceSchema);
const Booking = mongoose.model('Booking', BookingSchema);
const Promo = mongoose.model('Promo', PromoSchema);

// Seed helper route (for dev) - creates sample experiences if none exist
app.post('/seed', async (req, res) => {
  try {
    const count = await Experience.countDocuments();
    if(count > 0) return res.json({ seeded: false, reason: 'already seeded' });
    const examples = [
      {
        title: 'Sunset Kayaking',
        shortDescription: 'Kayak at sunset along scenic shores.',
        longDescription: 'Enjoy a guided kayak tour during sunset.',
        priceCents: 2500,
        imageUrl: 'https://images.unsplash.com/photo-1507525428034-b723cf961d3e',
        slots: [
          { startTime: new Date(Date.now() + 86400000), endTime: new Date(Date.now() + 90000000), availableSeats: 6 },
          { startTime: new Date(Date.now() + 2*86400000), endTime: new Date(Date.now() + 2*86400000 + 7200000), availableSeats: 6 }
        ]
      },
      {
        title: 'City Food Walk',
        shortDescription: 'Taste the city’s best street foods.',
        longDescription: 'A culinary walk visiting top street-food vendors.',
        priceCents: 1200,
        imageUrl: 'https://images.unsplash.com/photo-1524182576060-2d66b3b1d3b1',
        slots: [
          { startTime: new Date(Date.now() + 3*86400000), endTime: new Date(Date.now() + 3*86400000 + 10800000), availableSeats: 10 }
        ]
      }
    ];
    await Experience.create(examples);
    await Promo.create([{ code: 'SAVE10', type: 'percent', value: 10 }, { code: 'FLAT100', type: 'flat', value: 100 }]);
    return res.json({ seeded: true });
  } catch (err) {
    console.error(err);
    return res.status(500).json({ error: err.message });
  }
});

// GET /experiences
app.get('/experiences', async (req, res) => {
  const items = await Experience.find().lean().exec();
  res.json(items);
});

// GET /experiences/:id
app.get('/experiences/:id', async (req, res) => {
  try {
    const item = await Experience.findById(req.params.id).lean().exec();
    if(!item) return res.status(404).json({ error: 'not found' });
    res.json(item);
  } catch(e) {
    res.status(400).json({ error: 'invalid id' });
  }
});

// POST /promo/validate
app.post('/promo/validate', async (req, res) => {
  const { code, totalPriceCents } = req.body || {};
  if(!code) return res.status(400).json({ valid: false, reason: 'no code' });
  const promo = await Promo.findOne({ code }).lean().exec();
  if(!promo) return res.json({ valid: false });
  if(promo.expiresAt && new Date() > promo.expiresAt) return res.json({ valid: false, reason: 'expired' });
  let discountCents = 0;
  if(promo.type === 'percent') discountCents = Math.round((totalPriceCents * promo.value)/100);
  else if(promo.type === 'flat') discountCents = promo.value;
  res.json({ valid: true, discountCents, promo: { code: promo.code, type: promo.type, value: promo.value } });
});

// POST /bookings
app.post('/bookings', async (req, res) => {
  try {
    const { experienceId, slotId, userName, userEmail, numPeople, promoCode } = req.body;
    if(!experienceId || !slotId || !userName || !userEmail || !numPeople) {
      return res.status(400).json({ error: 'missing fields' });
    }

    // Transaction-like flow using session
    const session = await mongoose.startSession();
    session.startTransaction();
    try {
      const exp = await Experience.findById(experienceId).session(session);
      if(!exp) throw new Error('experience not found');
      const slot = exp.slots.id(slotId);
      if(!slot) throw new Error('slot not found');
      if(slot.availableSeats < numPeople) throw new Error('not enough seats');

      // calculate price
      let priceCents = (exp.priceCents || 0) * numPeople;
      if(promoCode) {
        const promo = await Promo.findOne({ code: promoCode }).session(session);
        if(promo) {
          if(promo.type === 'percent') priceCents = Math.max(0, Math.round(priceCents * (100 - promo.value)/100));
          else if(promo.type === 'flat') priceCents = Math.max(0, priceCents - promo.value);
        }
      }

      // decrement seats
      slot.availableSeats -= numPeople;
      await exp.save({ session });

      // create booking
      const booking = await Booking.create([{
        experienceId, slotId, userName, userEmail, numPeople, pricePaidCents: priceCents, promoCode
      }], { session });

      await session.commitTransaction();
      session.endSession();
      res.json({ success: true, booking: booking[0] });
    } catch(err) {
      await session.abortTransaction();
      session.endSession();
      res.status(400).json({ error: err.message });
    }
  } catch(err) {
    res.status(500).json({ error: err.message });
  }
});

const PORT = process.env.PORT || 5000;
app.listen(PORT, ()=> console.log('Server started on', PORT));
