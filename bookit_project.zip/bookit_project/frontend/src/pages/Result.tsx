import React from 'react'
import { useLocation, Link } from 'react-router-dom'

export default function Result(){
  const loc:any = useLocation()
  const booking = loc.state?.booking
  if(!booking) return <div>No booking info. <Link to="/">Home</Link></div>
  return (
    <div>
      <h1 className="text-2xl font-semibold">Booking Confirmed</h1>
      <div className="bg-white p-4 rounded shadow mt-4">
        <div><strong>Booking ID:</strong> {booking._id}</div>
        <div><strong>Name:</strong> {booking.userName}</div>
        <div><strong>Email:</strong> {booking.userEmail}</div>
        <div><strong>People:</strong> {booking.numPeople}</div>
        <div><strong>Amount paid:</strong> ₹{booking.pricePaidCents}</div>
      </div>
      <div className="mt-4"><Link to="/" className="text-indigo-600">Back to Home</Link></div>
    </div>
  )
}
