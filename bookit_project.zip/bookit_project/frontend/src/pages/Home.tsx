import React, {useEffect, useState} from 'react'
import { Link } from 'react-router-dom'
import { api } from '../lib/api'

export default function Home(){
  const [items, setItems] = useState<any[]>([])
  useEffect(()=>{
    api.get('/experiences').then(r=>setItems(r.data)).catch(()=>setItems([]))
  },[])
  return (
    <div>
      <h1 className="text-2xl font-semibold mb-4">Experiences</h1>
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
        {items.map(it=>(
          <div key={it._id} className="bg-white rounded-lg shadow p-4">
            <img src={it.imageUrl} alt="" className="w-full h-36 object-cover rounded-md mb-2" />
            <h2 className="font-semibold">{it.title}</h2>
            <p className="text-sm text-slate-600">{it.shortDescription}</p>
            <div className="mt-3 flex items-center justify-between">
              <div className="text-lg font-bold">₹{(it.priceCents||0)}</div>
              <Link to={'/experiences/'+it._id} className="text-indigo-600">View</Link>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
