import React from 'react'
import { useLocation, useNavigate } from 'react-router-dom'
import { api } from '../lib/api'

export default function Checkout(){
  const loc:any = useLocation()
  const navigate = useNavigate()
  const { experience, slot, numPeople } = loc.state || {}
  const [name, setName] = React.useState('')
  const [email, setEmail] = React.useState('')
  const [promo, setPromo] = React.useState('')
  const [applying, setApplying] = React.useState(false)
  const [discount, setDiscount] = React.useState(0)
  if(!experience || !slot) return <div>No booking data. Go back to home.</div>

  const total = (experience.priceCents||0) * (numPeople||1)
  const final = Math.max(0, total - discount)

  async function applyPromo(){
    if(!promo) return
    setApplying(true)
    try{
      const r = await api.post('/promo/validate', { code: promo, totalPriceCents: total })
      if(r.data.valid) setDiscount(r.data.discountCents || 0)
      else alert('Invalid promo')
    }catch(e){ alert('Error validating') }
    setApplying(false)
  }

  async function submitBooking(){
    try{
      const r = await api.post('/bookings', {
        experienceId: experience._id,
        slotId: slot._id,
        userName: name, userEmail: email, numPeople, promoCode: promo
      })
      if(r.data.success){
        navigate('/result', { state: { booking: r.data.booking } })
      } else {
        alert('Booking failed: ' + (r.data.error || 'unknown'))
      }
    }catch(e){
      alert('Booking error: ' + (e?.response?.data?.error || e.message))
    }
  }

  return (
    <div>
      <h1 className="text-xl font-semibold">Checkout</h1>
      <div className="bg-white p-4 rounded shadow mt-4">
        <div><strong>Experience:</strong> {experience.title}</div>
        <div><strong>Slot:</strong> {new Date(slot.startTime).toLocaleString()}</div>
        <div className="mt-2">
          <label className="block">Name</label>
          <input value={name} onChange={e=>setName(e.target.value)} className="w-full p-2 border rounded" />
        </div>
        <div className="mt-2">
          <label className="block">Email</label>
          <input value={email} onChange={e=>setEmail(e.target.value)} className="w-full p-2 border rounded" />
        </div>
        <div className="mt-2">
          <label className="block">Promo code</label>
          <div className="flex gap-2">
            <input value={promo} onChange={e=>setPromo(e.target.value)} className="p-2 border rounded flex-1" />
            <button onClick={applyPromo} disabled={applying} className="px-3 py-2 bg-indigo-600 text-white rounded">Apply</button>
          </div>
          {discount>0 && <div className="text-green-600 mt-2">Discount applied: ₹{discount}</div>}
        </div>

        <div className="mt-4">
          <div className="flex justify-between"><div>Total</div><div>₹{total}</div></div>
          <div className="flex justify-between"><div>Discount</div><div>- ₹{discount}</div></div>
          <div className="flex justify-between font-bold"><div>Pay</div><div>₹{final}</div></div>
        </div>

        <div className="mt-4">
          <button onClick={submitBooking} className="px-4 py-2 bg-green-600 text-white rounded">Pay & Book</button>
        </div>
      </div>
    </div>
  )
}
