import React, {useEffect, useState} from 'react'
import { useParams, useNavigate } from 'react-router-dom'
import { api } from '../lib/api'

export default function Details(){
  const { id } = useParams()
  const [item, setItem] = useState<any>(null)
  const [selectedSlot, setSelectedSlot] = useState<any>(null)
  const [numPeople, setNumPeople] = useState(1)
  const navigate = useNavigate()

  useEffect(()=>{
    if(!id) return
    api.get('/experiences/'+id).then(r=>setItem(r.data)).catch(()=>setItem(null))
  },[id])

  if(!item) return <div>Loading...</div>

  return (
    <div>
      <img src={item.imageUrl} alt="" className="w-full h-64 object-cover rounded-md mb-4" />
      <h1 className="text-2xl font-semibold">{item.title}</h1>
      <p className="text-slate-700 my-2">{item.longDescription || item.shortDescription}</p>

      <h3 className="mt-4 font-semibold">Available slots</h3>
      <div className="space-y-2 mt-2">
        {item.slots.map((s:any)=>(
          <div key={s._id} className={"p-3 border rounded "+(s.availableSeats<=0?'opacity-50':'')}>
            <div className="flex justify-between items-center">
              <div>
                <div>{new Date(s.startTime).toLocaleString()}</div>
                <div className="text-sm text-slate-500">{s.availableSeats} seats</div>
              </div>
              <div>
                <button disabled={s.availableSeats<=0} onClick={()=>{
                  setSelectedSlot(s); window.scrollTo({top:0,behavior:'smooth'});
                }} className="px-3 py-1 bg-indigo-600 text-white rounded disabled:bg-slate-300">Select</button>
              </div>
            </div>
          </div>
        ))}
      </div>

      {selectedSlot && (
        <div className="mt-4 p-4 bg-white rounded shadow">
          <h4 className="font-semibold">Booking</h4>
          <div className="mt-2 flex items-center gap-2">
            <label>People:</label>
            <input type="number" value={numPeople} min={1} onChange={e=>setNumPeople(Number(e.target.value))} className="w-20 p-1 border rounded" />
          </div>
          <div className="mt-3 flex gap-2">
            <button onClick={()=>{
              navigate('/checkout', { state: { experience: item, slot: selectedSlot, numPeople } })
            }} className="px-4 py-2 bg-green-600 text-white rounded">Proceed to Checkout</button>
          </div>
        </div>
      )}
    </div>
  )
}
