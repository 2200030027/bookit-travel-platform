# BookIt — Experiences & Slots (Minimal Starter)

This is a minimal fullstack starter for the BookIt assignment:
- Frontend: React + TypeScript (Vite) + TailwindCSS
- Backend: Express + MongoDB (Mongoose)
- Sample seed data included

## Quick steps

### Prerequisites
- Node.js (v18+)
- npm
- MongoDB running locally OR MongoDB Atlas connection string

### Run backend
```bash
cd backend
npm install
# set env in .env (example provided)
npm run dev
```

Default backend: http://localhost:5000

### Run frontend
```bash
cd frontend
npm install
npm run dev
```

Frontend default: http://localhost:5173

### Create ZIP (if needed)
From parent directory:
```bash
zip -r bookit.zip bookit_project
```

## Notes
- This is a minimal starter; customize UI to match Figma.
- Backend uses `MONGODB_URI` from `.env`. Example `.env.example` provided.
